import java.util.*;
public class gcd{
	public static int gcdnum(int a,int b){
		while(b!=0){
			int temp=b;
			b=a%b;
			a=temp;
		}
		return a;
	}
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the 1st number");
		int a=sc.nextInt();
		System.out.println("Enter the 2nd number");
		int b=sc.nextInt();
		int res=gcdnum(a,b);
		System.out.println("GCD of 2 numbers=>"+res);
	}
}