import java.util.*;
public class lcm{
	public static int gcdnum(int a,int b){
		while(b!=0){
			int temp=b;
			b=a%b;
			a=temp;
		}
		return a;
	}
	public static int lcmnum(int a,int b,int res){
		return (a*b)/res;
	}
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the 1st number");
		int a=sc.nextInt();
		System.out.println("Enter the 2nd number");
		int b=sc.nextInt();
		int res=gcdnum(a,b);
		int res2=lcmnum(a,b,res);
		System.out.println("LCM of 2 numbers=>"+res2);
	}
}