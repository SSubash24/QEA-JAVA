import java.util.*;
public class swapnum{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the 1st number");
		int a=sc.nextInt();
		System.out.println("Enter the 2nd number");
		int b=sc.nextInt();
		System.out.println("Number before Swap a=>"+a+" b=>"+b);
		int temp=a;
		a=b;
		b=temp;
		System.out.println("Number after Swap a=>"+a+" b=>"+b);
	}
}