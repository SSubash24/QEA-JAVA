import java.util.*;
public class temperature{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the temperature in Fahrenheit");
		double f=sc.nextDouble();
		sc.nextLine();
		double c=(f-32)/1.8;
		System.out.println("Temperature in celsius is "+c+"°C");
	}
}