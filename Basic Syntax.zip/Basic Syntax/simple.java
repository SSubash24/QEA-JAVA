import java.util.*;
public class simple{
	public static void main(String[]args){
		System.out.println("Subash");
	}
}