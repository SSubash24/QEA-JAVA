import java.util.*;
public class iscan{
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		String a=sc.nextLine();
		System.out.println("You entered");
		System.out.println(a);
	}
}