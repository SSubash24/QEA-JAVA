import java.util.Scanner;
class Factorial{
	public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a number to the end ");
	int a=sc.nextInt();
	System.out.println();
	}	
}